<?php
require('fpdf/fpdf.php');

class PDF extends FPDF {
    // Adiciona a imagem de fundo em todas as páginas
    function Header() {
        // Caminho para a imagem de fundo
        $this->Image('pbi.png', 0, 0, 297, 210); // Tamanho A4: 210x297 mm
        $this->SetFont('Arial', 'B', 16); // Usando a fonte padrão Arial
        $this->SetY(10); // Define a posição Y para o texto inicial
    }

    // Adiciona o rodapé (opcional)
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8); // Usando a fonte padrão Arial
        $this->Cell(0, 10, 'Pagina ' . $this->PageNo(), 0, 0, 'C');
    }
}

// Cria uma instância da classe PDF
$pdf = new PDF('L', 'mm', 'A4');

// Adiciona uma página
$pdf->AddPage();

// Define a fonte e adiciona o nome completo
$pdf->SetFont('Arial', 'B', 16); // Usando a fonte padrão Arial
$nomecompleto = isset($_POST['nomecompleto']) ? $_POST['nomecompleto'] : '';
$pdf->SetX(0);
$pdf->Cell(0, 150, "$nomecompleto", 0, 1, 'C');

// Define o nome do arquivo PDF a ser salvo
$nome_arquivo = $nomecompleto . ".pdf";

// Gera o PDF e faz o download
$pdf->Output('D', $nome_arquivo);
?>
