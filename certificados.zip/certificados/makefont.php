<?php
#require('fpdf/makefont/makefont.php');
#MakeFont('montserrat/static/Montserrat-Regular.ttf', 'cp1252');
exec("php fpdf/makefont/makefont.php montserrat/static/Montserrat-Regular.ttf cp1252");
?>